package Listener;

import org.bukkit.command.CommandSender;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class DebugLikeMeEvent
  extends Event
{
  private static final HandlerList handlers = new HandlerList();
  private CommandSender sender;
  private String path;
  private String plugin;
  
  public DebugLikeMeEvent(CommandSender player, String message)
  {
    setSender(player);
    String woord = "";
    for (String nu : message.split(" ")) {
      if (nu.startsWith("debugLikeMe")) {
        woord = nu;
      }
    }
    String[] woorden = woord.split(":");
    if (woorden.length == 1)
    {
      setPath("");
      setPlugin("");
    }
    if (woorden.length == 2)
    {
      setPath("");
      setPlugin(woorden[1]);
    }
    if (woorden.length == 3)
    {
      setPath(woorden[2]);
      setPlugin(woorden[1]);
    }
  }
  
  public HandlerList getHandlers()
  {
    return handlers;
  }
  
  public static HandlerList getHandlerList()
  {
    return handlers;
  }
  
  public CommandSender getSender()
  {
    return this.sender;
  }
  
  public void setSender(CommandSender sender)
  {
    this.sender = sender;
  }
  
  public String getPath()
  {
    return this.path;
  }
  
  public void setPath(String path)
  {
    this.path = path;
  }
  
  public String getPlugin()
  {
    return this.plugin;
  }
  
  public void setPlugin(String plugin)
  {
    this.plugin = plugin;
  }
}
