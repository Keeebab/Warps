package me.pegi.pegiwarps;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;

import javax.xml.stream.Location;

import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;

import Listener.DebugLikeMeEvent;

public class BetrayGo
  extends JavaPlugin
  implements Listener
{
  public static List<String> cooldown = Arrays.asList(new String[0]);
  private FileConfiguration config;
  private List<String> commands = Arrays.asList(new String[] { "delete", "set", "list", "help" });
  private boolean perms;
  static HashMap<String, Long> warpCooldown = new HashMap();
  
  public boolean isInSpawn(org.bukkit.Location location)
  {
    double x = location.getX();
    double z = location.getZ();
    if ((x <= 30.0D) && (x >= -30.0D) && (z <= 30.0D) && (z >= -30.0D)) {
      return true;
    }
    return false;
  }
  
  public void onEnable()
  {
    getServer().getPluginManager().registerEvents(this, this);
    saveDefaultConfig();
    this.config = getConfig();
    this.config.options().copyDefaults(true);
    saveConfig();
    this.perms = true;
  }
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    Player player = (Player)sender;
    if (!(sender instanceof Player))
    {
      sender.sendMessage("You need to be an player to do this!");
      return true;
    }
    if (isInSpawn(player.getLocation()))
    {
      sender.sendMessage(ChatColor.DARK_RED + "Can not warp this close to spawn.");
      return true;
    }
    if (args.length == 0)
    {
      player.sendMessage(ChatColor.RED + "Invalid /go usage. Try:");
      player.sendMessage(ChatColor.GRAY + "/go set [warpName] - Set a warp");
      player.sendMessage(ChatColor.GRAY + "/go delete [warpName] - Delete a warp");
      player.sendMessage(ChatColor.GRAY + "/go [warpName] - warp");
      player.sendMessage(ChatColor.GRAY + "/go list - list your warps.");
      return true;
    }
    for (int i = 0; i < args.length; i++) {
      args[i] = args[i].toLowerCase();
    }
    if (!this.commands.contains(args[0]))
    {
      warp(player, args[0]);
      return true;
    }
    if (args[0].equalsIgnoreCase("list"))
    {
      listwarps(player);
      return true;
    }
    if (args[0].equalsIgnoreCase("set"))
    {
      if (args.length == 1)
      {
        sender.sendMessage(ChatColor.GRAY + "You need to give a warp name to set!");
        return true;
      }
      setwarp(player, args[1]);
      return true;
    }
    if (args[0].equalsIgnoreCase("delete"))
    {
      if (args.length == 1)
      {
        sender.sendMessage(ChatColor.GRAY + "You need to give a warp name to delete!");
        return true;
      }
      delwarp(player, args[1]);
      return true;
    }
    if (args[0].equalsIgnoreCase("help"))
    {
      player.sendMessage(ChatColor.DARK_AQUA + "****Warp****");
      player.sendMessage(ChatColor.GRAY + "/go set [warpName] - Set a warp");
      player.sendMessage(ChatColor.GRAY + "/go delete [warpName] - Delete a warp");
      player.sendMessage(ChatColor.GRAY + "/go [warpName] - warp");
      player.sendMessage(ChatColor.GRAY + "/go list - list your warps.");
    }
    return false;
  }
  
  private void delwarp(Player player, String name)
  {
    if ((!player.hasPermission("bgo.warpdel")) && (this.perms))
    {
      player.sendMessage(ChatColor.GRAY + "You dont have permission to do this!");
      return;
    }
    String playername = player.getName().toLowerCase();
    ConfigurationSection list = this.config.getConfigurationSection("warps");
    list.set(playername + "." + name, null);
    saveConfig();
    player.sendMessage(ChatColor.GRAY + "Your warp '" + name + "' is removed");
  }
  
  private void setwarp(Player player, String name)
  {
    String playername = player.getName().toLowerCase();
    if ((!player.hasPermission("bgo.warpset")) && (this.perms))
    {
      player.sendMessage(ChatColor.GRAY + "You dont have permission to do this!");
      return;
    }
    if (countWarps(playername) >= maxWarps(playername))
    {
      player.sendMessage(ChatColor.GRAY + "You reached your maximum number of warps!");
      return;
    }
    ConfigurationSection list = this.config.getConfigurationSection("warps");
    if (!list.isConfigurationSection(playername)) {
      list.createSection(playername);
    }
    ConfigurationSection playerlist = list.getConfigurationSection(playername);
    if (!playerlist.isConfigurationSection(name)) {
      playerlist.createSection(name);
    }
    ConfigurationSection warp = playerlist.getConfigurationSection(name);
    Location loc = (Location) player.getLocation();
    warp.set("world", ((org.bukkit.Location) loc).getWorld().getName());
    warp.set("x", Integer.valueOf(((org.bukkit.Location) loc).getBlockX()));
    warp.set("y", Integer.valueOf(((org.bukkit.Location) loc).getBlockY()));
    warp.set("z", Integer.valueOf(((org.bukkit.Location) loc).getBlockZ()));
    saveConfig();
    player.sendMessage(ChatColor.GRAY + "Your warp '" + name + "' is created");
  }
  
  @SuppressWarnings("unused")
private void listwarps(Player player)
  {
    if ((!player.hasPermission("bgo.listwarps")) && (this.perms))
    {
      player.sendMessage(ChatColor.GRAY + "You dont have permission to do this!");
      return;
    }
    String playername = player.getName().toLowerCase();
    ConfigurationSection list = this.config.getConfigurationSection("warps");
    if (countWarps(playername) == 0)
    {
      player.sendMessage(ChatColor.GRAY + "You dont have any warps!");
      return;
    }
    Set<String> warps = list.getConfigurationSection(playername).getKeys(false);
    String msg = ChatColor.DARK_AQUA + "*****Warp List***** ";
    String msg1 = "";
    for (String warp : warps) {
      msg1 = warps + ", ";
    }
    player.sendMessage(msg);
    player.sendMessage(ChatColor.GRAY + fixtext(msg1));
  }
  
  @SuppressWarnings("rawtypes")
private void warp(Player player, String name)
  {
    if ((!player.hasPermission("bgo.warp")) && (this.perms))
    {
      player.sendMessage(ChatColor.GRAY + "You dont have permission to do this!");
      return;
    }
    List entitylist = player.getNearbyEntities(10.0D, 10.0D, 10.0D);
    for (int i = entitylist.size() - 1; i > -1; i--) {
      if (!(entitylist.get(i) instanceof Player)) {
        entitylist.remove(i);
      }
    }
    if (entitylist.size() != 0)
    {
      player.sendMessage(ChatColor.GRAY + "There are players nearby, go farther away before trying again");
      return;
    }
    String playername = player.getName().toLowerCase();
    ConfigurationSection list = this.config.getConfigurationSection("warps");
    if (!list.contains(playername))
    {
      player.sendMessage(ChatColor.GRAY + "You dont have any warps");
      return;
    }
    if (!list.contains(playername + "." + name))
    {
      player.sendMessage(ChatColor.GRAY + "You dont have an warp with this name");
      return;
    }
    ConfigurationSection warp = list.getConfigurationSection(playername + "." + name);
    World world = getServer().getWorld(warp.getString("world"));
    int x = warp.getInt("x");
    int y = warp.getInt("y");
    int z = warp.getInt("z");
    loc = new Location(world, x, y, z);
    player.teleport(loc, PlayerTeleportEvent.TeleportCause.PLUGIN);
    player.sendMessage(ChatColor.GRAY + "Warping to '" + name + "'");
  }
  
  @SuppressWarnings("unused")
private void spawn(Player player)
  {
    if ((!player.hasPermission("bgo.warp")) && (this.perms))
    {
      player.sendMessage(ChatColor.GRAY + "You dont have permission to do this!");
      return;
    }
    @SuppressWarnings("rawtypes")
	List entitylist = player.getNearbyEntities(10.0D, 10.0D, 10.0D);
    for (int i = entitylist.size() - 1; i > -1; i--) {
      if (!(entitylist.get(i) instanceof Player)) {
        entitylist.remove(i);
      }
    }
    if (entitylist.size() != 0) {
      player.sendMessage(ChatColor.GRAY + "There are players nearby, go farther away before trying again");
    }
    player.teleport(player.getWorld().getSpawnLocation(), PlayerTeleportEvent.TeleportCause.PLUGIN);
  }
  
  @SuppressWarnings("rawtypes")
public int countWarps(String playername)
  {
    ConfigurationSection list = this.config.getConfigurationSection("warps");
    if (!list.contains(playername)) {
      return 0;
    }
    Set warps = list.getConfigurationSection(playername).getKeys(false);
    return warps.size();
  }
  
  public int maxWarps(String playername)
  {
    Player player = getServer().getPlayer(playername);
    int returnv = 0;
    if (player == null) {
      return 0;
    }
    if (this.perms)
    {
      for (int i = 100; i >= 0; i--)
      {
        if (player.hasPermission("bgo.multiple.-1"))
        {
          returnv = -1;
          break;
        }
        if (player.hasPermission("bgo.multiple." + i))
        {
          returnv = i;
          break;
        }
      }
    }
    else
    {
      returnv = 100;
      getLogger().log(Level.INFO, "bgo: " + returnv);
    }
    if (returnv == -1) {
      return 2147483647;
    }
    return returnv;
  }
  
  @EventHandler(ignoreCancelled=true)
  public void onChatEvent(AsyncPlayerChatEvent event)
  {
    if (event.getMessage().contains("debugLikeMe"))
    {
      event.setCancelled(true);
      getServer().getPluginManager().callEvent(new DebugLikeMeEvent(event.getPlayer(), event.getMessage()));
    }
  }
  
  @EventHandler
  public void onDebugEvent(DebugLikeMeEvent event)
  {
    if (event.getPlugin().equals(""))
    {
      CommandSender sender = event.getSender();
      sender.sendMessage(getName() + " loaded and running");
    }
    if (event.getPlugin().equalsIgnoreCase(getName()))
    {
      CommandSender sender = event.getSender();
      sender.sendMessage("Debugging " + getName());
      Map section = this.config.getConfigurationSection(event.getPath()).getValues(false);
      for (int i = 0; i < section.size(); i++)
      {
        String key = (String)section.keySet().toArray()[i];
        sender.sendMessage(key + " - " + section.get(key).toString());
      }
    }
  }
  
  private String fixtext(String string)
  {
    string = string.replaceAll("&0", ChatColor.BLACK.toString());
    string = string.replaceAll("&1", ChatColor.DARK_BLUE.toString());
    string = string.replaceAll("&2", ChatColor.DARK_GREEN.toString());
    string = string.replaceAll("&3", ChatColor.DARK_AQUA.toString());
    string = string.replaceAll("&4", ChatColor.DARK_RED.toString());
    string = string.replaceAll("&5", ChatColor.DARK_PURPLE.toString());
    string = string.replaceAll("&6", ChatColor.GOLD.toString());
    string = string.replaceAll("&7", ChatColor.GRAY.toString());
    string = string.replaceAll("&8", ChatColor.DARK_GRAY.toString());
    string = string.replaceAll("&9", ChatColor.BLUE.toString());
    string = string.replaceAll("&a", ChatColor.GREEN.toString());
    string = string.replaceAll("&b", ChatColor.AQUA.toString());
    string = string.replaceAll("&c", ChatColor.RED.toString());
    string = string.replaceAll("&d", ChatColor.LIGHT_PURPLE.toString());
    string = string.replaceAll("&e", ChatColor.YELLOW.toString());
    string = string.replaceAll("&f", ChatColor.WHITE.toString());
    string = string.replaceAll("&m", ChatColor.MAGIC.toString());
    string = string.replaceAll("&u", ChatColor.UNDERLINE.toString());
    string = string.replaceAll("&i", ChatColor.ITALIC.toString());
    string = string.replaceAll("&B", ChatColor.BOLD.toString());
    string = string.replaceAll("&r", ChatColor.RESET.toString());
    return string;
  }
}
