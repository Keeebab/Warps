package me.pegi.pegiwarps;

import java.util.List;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

@SuppressWarnings("unused")
public class Cooldown
  extends BukkitRunnable
{
  private String name;
  
  public Cooldown(String name, int time, JavaPlugin plugin)
  {
    name = name.toLowerCase();
    this.name = name;
    BetrayGo.cooldown.add(name);
    runTaskLater(plugin, time * 20);
  }
  
  public void run()
  {
    BetrayGo.cooldown.remove(this.name);
  }
}
